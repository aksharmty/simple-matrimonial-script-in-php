<LINK href="style.css" rel="stylesheet" type="text/css">
<!-- ''''''''''''''NORMAL ''''''''''''''' -->
<body bgcolor="#CCCCCC"><table width="100%" border="0" cellspacing="1" cellpadding="1">
  <tr>
    <td><table width="170" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td><img src="pics/Lmenutop.png" width="170" height="25" /></td>
      </tr>
      <tr>
        <td height="25" background="pics/Lmenumid.png"><table width="150" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td width="7"><img height="5" 
                                src="pics/pics/Redarrowbullent.gif" 
                                width="7" /></td>
              <td width="97"><div align="left">&nbsp;&nbsp;<a class="black" href="membershipschemes.php"><span class="bodylink">Membership Schemes</span></a></div></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td background="pics/Lmenumid.png"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td background="pics/reddot.gif"></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td height="25" background="pics/Lmenumid.png"><table width="160" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td width="7"><img height="5" 
                                src="pics/pics/Redarrowbullent.gif" 
                                width="7" /></td>
              <td width="97"><div align="left">&nbsp;&nbsp;<a class="black" href="becomedealer.php"><span class="bodylink">Become a Dealer/Agent</span></a><a class="black" href="search.php"></a></div></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td background="pics/Lmenumid.png"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td background="pics/reddot.gif"></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td height="25" background="pics/Lmenumid.png"><table width="150" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td><img height="5" 
                                src="pics/pics/Redarrowbullent.gif" 
                                width="7" /></td>
              <td><div align="left">&nbsp;&nbsp;<a class="black" href="paymentoptions.php"><span class="bodylink">Payment Option</span></a></div></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td background="pics/Lmenumid.png"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td background="pics/reddot.gif"></td>
            </tr>
        </table></td>
      </tr>
      
      <tr>
        <td height="25" background="pics/Lmenumid.png"><table width="150" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td><img height="5" 
                                src="pics/pics/Redarrowbullent.gif" 
                                width="7" /></td>
              <td><div align="left">&nbsp;&nbsp;<a class="black" href="referafriend.php"><span class="bodylink">Refer a Friend</span></a><a class="black" href="search.php"></a></div></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td background="pics/Lmenumid.png"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td background="pics/reddot.gif"></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td height="25" background="pics/Lmenumid.png"><table width="150" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td><img height="5" 
                                src="pics/pics/Redarrowbullent.gif" 
                                width="7" /></td>
              <td><div align="left">&nbsp;&nbsp;<a class="black" href="addhoroshelp.php"><span class="bodylink">Adding Horoscope</span></a></div></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td background="pics/Lmenumid.png"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td background="pics/reddot.gif"></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td height="25" background="pics/Lmenumid.png"><table width="150" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td><img height="5" 
                                src="pics/pics/Redarrowbullent.gif" 
                                width="7" /></td>
              <td><div align="left">&nbsp;&nbsp;Adding Photograph<a class="black" href="addphotohelp.php"><span class="bodylink"> </span></a><a class="black" href="search.php"></a></div></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td background="pics/Lmenumid.png"><table width="155" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td background="pics/reddot.gif"></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td height="25" background="pics/Lmenumid.png"><table width="150" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td width="7"><img height="5" 
                                src="pics/pics/Redarrowbullent.gif" 
                                width="7" /></td>
              <td width="97"><div align="left">&nbsp;&nbsp;<a class="black" href="faq.php"><span class="bodylink">FAQ</span></a><a class="black" href="search.php"></a></div></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td height="25" background="pics/Lmenumid.png">&nbsp;</td>
      </tr>
      <tr>
        <td><img src="pics/Lmenubot.png" width="170" height="11" /></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td><!-- ''''''''''''''MEMBER ONLY''''''''''''''''''' --></td>
  </tr>
</table>
