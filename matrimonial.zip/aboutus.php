<?php include("config.php"); ?>



<HTML>
<HEAD>
<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $info['Title']; ?></title>
<meta name="Description" content="<?php echo $info['Description']; ?>">
<meta name="keywords" content="<?php echo $info['Keywords']; ?>">
<LINK href="style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style1 {
	color: #FF6633;
	font-weight: bold;
}
-->
</style>
</HEAD>
<BODY class="body">



<DIV align="center">
<TABLE width="780" border="0" align="center" cellpadding="0" cellspacing="0" class="BlueTborder">
          <!--DWLayoutTable-->
          <TR>
            <TD height="37" colspan="2">
			<?php include("header.php");?>
			</TD>
    </TR>
          <TR>
            
    </TR>
          <TR>
            <TD  colspan="2"><?php include("topmenu.php");?></TD>
          </TR>
          <TR bgcolor="#FFFFFF">
            <TD colspan="2" valign="top">
			  

  
<!-- START LEFT PART -->  
<DIV align="center">
<TABLE width="100%" border="0" cellpadding="0" cellspacing="0">
<TR>
<TD width="180" height="303" valign="top" bgcolor="#F5F5F5">
<?php include("left.php");?>
<?php include("leftbanner.php");?>
</TD>
<TD valign="top"><br>
      <table width="97%" height="20" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="37%" background="pics/heading_bg.gif"><div align="left">&nbsp;&nbsp;<strong>About Us </strong></div></td>
          <td width="63%">&nbsp;</td>
        </tr>
      </table>
       
      <table width="97%" border="0" align="center" cellpadding="0" cellspacing="0" class="submenubox">
  <tr>
    <td><table width="98%" border="0" align="center" cellpadding="5" cellspacing="5">
      
      <tr>
        <td width="86%" valign="top"><p align="justify"><STRONG><?php echo $info['WebFriendlyname']; ?></STRONG> is for South Asians all over the   world to help them find their life partners. <br>
            <br>
In the past, hundreds of thousands   of people have met their life partners through a family &ldquo;<?php echo $info['WebFriendlyname']; ?>&rdquo; now we bring   you the virtual &ldquo;<?php echo $info['WebFriendlyname']; ?>&rdquo; matchmaking service.</p>          
          <p align="justify"><STRONG><?php echo $info['WebFriendlyname']; ?> </STRONG>was conceived with one simple   objective - to provide a superior matchmaking experience by expanding the   opportunities available to meet potential life partners. We have set a goal to   create a service that will touch the lives of millions of people all over the   world.</p>
          <p align="justify"><STRONG><?php echo $info['WebFriendlyname']; ?> </STRONG>understands the needs and concerns   of singles all over the world.<BR>
              <?php echo $info['WebFriendlyname']; ?> will provide a pleasant,   satisfying, and matchmaking experience to our customers <BR>
  &nbsp;<BR>
  <STRONG><?php echo $info['WebFriendlyname']; ?></STRONG> will let you have complete control of   finding your life partner through easy to use interfaces and features that can   help them identify, filter and contact potential partners </p>
          <p align="justify"><STRONG><?php echo $info['WebFriendlyname']; ?></STRONG> is the NEW matrimonial service   partner, you and your friend will be using to find your life partner.</p>
          <p align="justify"><STRONG><?php echo $info['WebFriendlyname']; ?></STRONG> is backed by an unconditional   guarantee that your experience of our service, you will want to recommend us to   your friends.</p>
          <p align="justify">Please take some time to get to know your &ldquo;<?php echo $info['WebFriendlyname']; ?>&rdquo; better by   surfing all the pages. Perhaps the information will help you decide if we are   the right solution for you or somebody you know.</p></td>
        </tr>
      
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
      <p>&nbsp;</p></TD>
</TR>
</TABLE>

</DIV>
<!-- END LEFT PART -->	


		  
		    </TD>
    </TR>
			
          <TR>
            <TD><?php include("footer.php");?></TD>
          </TR>
          <TR>
          
    </TR>
          <TR>
         
          </TR>
  </TABLE>
  
</DIV>




</BODY>
</HTML>
