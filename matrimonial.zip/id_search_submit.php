<?
$Strid = $_POST['txtID'];
header ("Location:viewprofile.php?id=$Strid");
?>


