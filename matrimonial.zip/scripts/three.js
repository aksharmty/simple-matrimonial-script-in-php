<!-- Begin
three = new Array(
new Array(
new Array("--Select Sub Category--", ""),
new Array("selva1", "selva1"),
new Array("Women Apparels", "selva2"),
new Array("Kids Apparels", "selva3"),
new Array("Accessories", "selva4"),
new Array("Others: Apparels ans Accessories", "Others: Apparels and Accessories")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Astrology / Numerology", "Astrology / Numerology"),
new Array("Vaasthu / Feng Shui", "Vaasthu / Feng Shui"),
new Array("Others: Astro Services", "Others: Astro Services")

),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Two Wheelers", "Two Wheelers"),
new Array("Four Wheelers", "Four Wheelers"),
new Array("Commercial Carriers", "Commercial Carriers"),
new Array("Auto Finance", "Auto Finance"),
new Array("Dealers", "Dealers"),
new Array("Spares / Accessories", "Spares / Accessories"),
new Array("Service Centers", "Service Centers"),
new Array("Others: Automobiles", "Others: Automobiles")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Beauty Parlors", "Beauty Parlors"),
new Array("Beauty Products", "Beauty Products"),
new Array("Others: Beauty", "Others: Beauty")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Novels", "Novels"),
new Array("Educational Books", "Educational Books"),
new Array("Magazines / Periodicals", "Magazines / Periodicals"),
new Array("Others: Books and Magazines", "Others: Books and Magazines")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Agents / Partnerships / Franchisees", "Agents / Partnerships / Franchisees"),
new Array("Home Based Business", "Home Based Business"),
new Array("Multi-Level Marketing", "Multi-Level Marketing"),
new Array("Manufacturers", "Manufacturers"),
new Array("Exporters", "Exporters"),
new Array("Importers", "Importers"),
new Array("Traders", "Traders"),
new Array("Service Providers", "Service Providers"),
new Array("Others: Business Opportunities", "Others: Business Opportunities")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Video and Computer Games", "Video and Computer Games"),
new Array("Gaming Accessories", "Gaming Accessories"),
new Array("Others: Computer / Video Games", "Others: Computer / Video Games")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Computer Hardware", "Computer Hardware"),
new Array("Computer Software", "Computer Software"),
new Array("Computer Peripherals", "Computer Peripherals"),
new Array("Services", "Services"),
new Array("Others: Computers", "Others: Computers")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Housemaid", "Housemaid"),
new Array("Dry Cleaners", "Dry Cleaners"),
new Array("Repairs / Maintenance Services", "Repairs / Maintenance Services"),
new Array("Pest Control", "Pest Control"),
new Array("Movers & Packers", "Movers & Packers"),
new Array("Others: Domestic Services", "Others: Domestic Services")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Creches, Kinder Garden / Play Schools", "Creches, Kinder Garden / Play Schools"),
new Array("Educational Institutions", "Educational Institutions"),
new Array("Coaching and Training Centers", "Coaching and Training Centers"),
new Array("School", "School"),
new Array("Others: Education", "Others: Education")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Audio Equipments", "Audio Equipments"),
new Array("Video Equipments", "Video Equipments"),
new Array("Cameras / Camcorders", "Cameras / Camcorders"),
new Array("Others: Electronics", "Others: Electronics")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Loans", "Loans"),
new Array("Insurance", "Insurance"),
new Array("Investments", "Investments"),
new Array("Consultants", "Consultants"),
new Array("Others: Financial Services", "Others: Financial Services")
),

new Array(
new Array("--Select Sub Category--", ""),
new Array("Consultants", "1"),
new Array("Fitness / Sports Centers", "2"),
new Array("Fitness / Sports Products", "3"),
new Array("Others: Fitness & Sports", "4")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Restaurants", "Restaurants"),
new Array("Caterers", "Caterers"),
new Array("Bakers and Confectioners", "Bakers and Confectioners"),
new Array("Water Suppliers", "Water Suppliers"),
new Array("Others: Food and Beverages", "Others: Food and Beverages")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Health Professionals", "Health Professionals"),
new Array("Hospitals/Pharmacy", "Hospitals/Pharmacy"),
new Array("Health Care Products", "Health Care Products"),
new Array("Others: Health", "Others: Health")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Home Appliances", "Home Appliances"),
new Array("Fittings, Furniture", "Fittings, Furniture"),
new Array("Art and Antiques, Handicrafts", "Art and Antiques, Handicrafts"),
new Array("Office Stationeries", "Office Stationeries"),
new Array("Others: Household and Office Products", "Others: Household and Office Products")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Gold and Silver", "Gold and Silver"),
new Array("Precious Stones", "Precious Stones"),
new Array("Imitation Jewellery", "Imitation Jewellery"),
new Array("Others: Jewellery", "Others: Jewellery")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Jobs Available", "Jobs Available"),
new Array("Jobs Wanted", "Jobs Wanted"),
new Array("HR Consultancies", "HR Consultancies"),
new Array("Others: Jobs", "Others: Jobs")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Prohit", "Prohit"),
new Array("Marriage Halls", "Marriage Halls"),
new Array("Catering / Marriage Contractors", "Catering / Marriage Contractors"),
new Array("Wedding Cards, Gifts, Florists", "Wedding Cards, Gifts, Florists"),
new Array("Grooms Wanted", "Grooms Wanted"),
new Array("Brides Wanted", "Brides Wanted"),
new Array("Photo / Videographers", "Photo / Videographers"),
new Array("Wedding Music", "Wedding Music"),
new Array("Others: Matrimony Services", "Others: Matrimony Services")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Mobile Handsets", "Mobile Handsets"),
new Array("Games / Ring Tones", "Games / Ring Tones"),
new Array("Telephone Accessories", "Telephone Accessories"),
new Array("Others: Mobile and Telephone", "Others: Mobile and Telephone")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Audio", "Audio"),
new Array("Video", "Video"),
new Array("Musical Instruments", "Musical Instruments"),
new Array("Music Classes", "Music Classes"),
new Array("Entertainers", "Entertainers"),
new Array("Dance", "Dance"),
new Array("Others: Music and Entertainment", "Others: Music and Entertainment")

),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Pets", "Pets"),
new Array("Veterinary Doctors / Trainers", "Veterinary Doctors / Trainers"),
new Array("Pet Products", "Pet Products"),
new Array("Others: Pets and Pets Care", "Others: Pets and Pets Care")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Property For Sale", "Property For Sale"),
new Array("Property Wanted", "Property Wanted"),
new Array("Builders / Agents / Realtors", "Builders / Agents / Realtors"),
new Array("Architects / Interiors", "Architects / Interiors"),
new Array("Home Loan", "Home Loan"),
new Array("Rentals, Paying Guest, Guest House", "Rentals, Paying Guest, Guest House"),
new Array("Room-Mates, Hostels", "Room-Mates, Hostels"),
new Array("Others: Real Estate", "Others: Real Estate")

),

new Array(
new Array("--Select Sub Category--", ""),
new Array("Private Security Services", "Private Security Services"),
new Array("Detective Agencies", "Detective Agencies"),
new Array("Others: Security Services", "Others: Security Services")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Hotels & Resorts", "Hotels & Resorts"),
new Array("Travel Agents", "Travel Agents"),
new Array("Ticketing Services", "Ticketing Services"),
new Array("Money Changers", "Money Changers"),
new Array("mmigration Consultancy", "mmigration Consultancy"),
new Array("Car Rentals", "Car Rentals"),
new Array("Others: Tours, Travel and Transport", "Others: Tours, Travel and Transport")
),
new Array(
new Array("--Select Sub Category--", ""),
new Array("Miscellaneous", "Miscellaneous")

),

null,
new Array(
new Array("", "")
)
);

function fillSelectFromArray(selectCtrl, itemArray, goodPrompt, badPrompt, defaultItem) {
var i, j;
var prompt;
// empty existing items

for (i = selectCtrl.options.length; i >= 0; i--) {
selectCtrl.options[i] = null; 
}
prompt = (itemArray != null) ? goodPrompt : badPrompt;
if (prompt == null) {
j = 0;
}
else {
selectCtrl.options[0] = new Option(prompt);
j = 1;
}

if (itemArray != null) {
// add new items
for (i = 0; i < itemArray.length; i++) {
selectCtrl.options[j] = new Option(itemArray[i][0]);
if (itemArray[i][1] != null) {
selectCtrl.options[j].value = itemArray[i][1]; 


if (itemArray[i][1]==defaultItem)
{
	
	selectCtrl.options[j].selected = true;
}
}
j++;
}
// select first item (prompt) for sub list
//selectCtrl.options[0].selected = true;
   }
}
//  End -->
