<?php
// This is for Mysql Database Connection String File for Remote Machine
ob_start();
$con = mysqli_connect('localhost', 'adquash1_sunita', '1k[~u,J5asol', 'adquash1_matri');
if ($con->connect_error) {
  die("Connection failed: " . $con->connect_error);
}
?>
