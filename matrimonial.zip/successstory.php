<?php include("config.php"); ?>
<? // Database Connection 
include 'dbconnect.php'; 

// If current page number, use it 
// if not, set one! 

if(!isset($_GET['page'])){ 
    $page = 1; 
} else { 
    $page = $_GET['page']; 
} 

$max_results = 5; 
$from = (($page * $max_results) - $max_results);  
$sql = mysqli_query($con,"SELECT *,Left(successmessage ,200) as successmessageshort FROM successstory where approve ='Yes' order by ID desc LIMIT $from, $max_results"); 

?>

<HTML>
<HEAD>
<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $info['Title']; ?></title>
<meta name="Description" content="<?php echo $info['Description']; ?>">
<meta name="keywords" content="<?php echo $info['Keywords']; ?>">
<LINK href="style.css" rel="stylesheet" type="text/css">

<SCRIPT language="Javascript">
<!--
<!--
<!--
		function validate2( )
		{
			var photoform = this.document.photoform;

			if ( photoform.uploaded_file.value == "" )
			{
				alert( "Please select your Image file." );
				photoform.uploaded_file.focus( );
				return false;
			}

			var     extPos = photoform.uploaded_file.value.lastIndexOf( "." );
            if ( extPos == - 1)
            {
                alert( "Only Jpg or Gif or Png files can be added." );
				photoform.uploaded_file.focus( );
				return false;
			}
            else
            {
				var extn =  photoform.uploaded_file.value.substring(
					extPos + 1, photoform.uploaded_file.value.length );
				if ( extn != "jpeg" && extn != "jpg" && extn != "gif" && extn != "png" )
				{
                	alert( "Only Jpg or Gif or Png files can be added." );
					photoform.uploaded_file.focus( );
					return false;
				}
				
				
				var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?0123456789";

  for (var i = 0; i < photoform.BrideName.value.length; i++) {
  	if (iChars.indexOf(photoform.BrideName.value.charAt(i)) != -1) {
  	alert ("Special characters and numbers are not allowed in Bride Name.\n Please remove them.");
	photoform.BrideName.focus( );
  	return false;
  	}
  }
  
  var jChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?0123456789";

  for (var j = 0; j < photoform.GroomName.value.length; j++) {
  	if (jChars.indexOf(photoform.GroomName.value.charAt(j)) != -1) {
  	alert ("Special characters and numbers are not allowed in Groom Name.\n Please remove them.");
	photoform.GroomName.focus( );
  	return false;
  	}
  }

var kChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";

  for (var k = 0; k < photoform.Message.value.length; k++) {
  	if (kChars.indexOf(photoform.Message.value.charAt(k)) != -1) {
  	alert ("Special characters are not allowed in Message.\n Please remove them.");
	photoform.Message.focus( );
  	return false;
  	}
  }
				
				
				
			}
			return true;
		}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->


</SCRIPT>



</HEAD>


<style type="text/css">
		
		div.wrapper {
			margin:0 auto;
			padding:5px;
			width:620px;
			border:1px solid #35528F;
		}
		h1 {
			padding:8px;
			margin:0px;
		}
		div.errors {
			color:#FF0000;
		}
		ul {
			list-style:none;
			padding:5px;
		}
		ul li {
			display:inline;
			padding-right:12px;
		}
		p.footer {
			clear:both;
			text-align:center;
			font-size:10px;
		}
		div.block {
			float:left;
			width:300px;
		}
		div.errors {
			color:red;
		}
	</style>



<BODY class="body">



<DIV align="center">
<TABLE width="780" border="0" align="center" cellpadding="0" cellspacing="0" class="BlueTborder">
          <!--DWLayoutTable-->
          <TR>
            <TD height="37" colspan="2">
			<?php include("header.php");?>
			</TD>
    </TR>
          <TR>
            
    </TR>
          <TR>
            <TD  colspan="2"><?php include("topmenu.php");?></TD>
          </TR>
          <TR bgcolor="#FFFFFF">
            <TD colspan="2" valign="top">
			  

  
<!-- START LEFT PART -->  
<DIV align="center">
<TABLE width="100%" border="0" cellpadding="0" cellspacing="0">
<TR>
  <TD height="200" valign="top" ><br>
  <table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="544" valign="top">
	
	  <table width="97%" height="20" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="40%" background="pics/heading_bg.gif"><div align="left">&nbsp;&nbsp;<strong>Success Story  </strong></div></td>
          <td width="60%">&nbsp;</td>
        </tr>
      </table>
	  <table width="97%" border="0" align="center" cellpadding="0" cellspacing="0" class="submenubox">
        <tr>
          <td><table width="98%" border="0" align="center" cellpadding="3" cellspacing="3">
            <tr>
              <td><?php
// Figure out the total number of results in DB: 
$total_results = mysqli_fetch_assoc(mysqli_query($con,"SELECT COUNT(id) as Num FROM successstory where approve ='Yes' ")); 
	/*
	if($total_results ==0)
	{
	print "<script>";
     print "self.location='noresults.php';"; // Comment this line if you don't want to redirect
     print "</script>";
	}
	
*/
echo "";
$total = $total_results["Num"];
// Figure out the total number of pages. Always round up using ceil() 
$total_pages = ceil($total / $max_results);

?>
                  <span class="Partext1"><?php echo " " . $total_results ." Success Stories Found" ?></span></td>
              <td><div align="right"><span class="Partext1">
                  <?php

//Paging info
echo "Page ";


for($i = 1; $i <= $total_pages; $i++){ 
    if(($page) == $i){ 
        echo "$i "; 
        } else { 
            echo "&nbsp;[ <a href=\"".$_SERVER['PHP_SELF']."?page=$i\">$i</a>  ] "; 
    } 
} 


echo " of ". $total_pages ; 


// Build Previous Link 
if($page > 1){ 
    $prev = ($page - 1); 
    //echo "Page &nbsp;<a href=\"".$_SERVER['PHP_SELF']."?page=$prev\"><<Previous</a> "; 
	echo "&nbsp;<a href=\"".$_SERVER['PHP_SELF']."?page=$prev\"> Previous</a> &nbsp;|";
} 

// Build Next Link 
if($page < $total_pages){ 
    $next = ($page + 1); 
    echo "&nbsp;<a href=\"".$_SERVER['PHP_SELF']."?page=$next\">Next</a>"; 
} 
?>
              </span></div></td>
            </tr>
          </table>
            <table width="98%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td></td>
              </tr>
            </table>
            <table width="98%" border="0" align="center" cellpadding="4" cellspacing="0">
              <?php while($row = $sql->fetch_array()){ ?>
              <tr>
                <td width="6%" ><img src="photoprocess.php?image=SuccessStory_Photos/<?php echo $row['weddingphoto']?>&square=100&watermark_text=<?php echo $info['Webname']; ?>&watermark_color=ffffff;" alt="<?php echo $row['groomname']?>-<?php echo $row['bridename']?>" border="0" class="submenubox"/> </td>
                <td width="94%" valign="top" ><span class="h3r"><?php echo $row['groomname']?> &amp; <?php echo $row['bridename']?></span> <br>
                  <?php echo $row['successmessageshort']?>&nbsp; <a href="#" onClick="MM_openBrWindow('sucsess_stroryread.php?id=<?php echo $row['ID']?>','ss','scrollbars=yes,width=450,height=500')">more ....</a> </td>
              </tr>
              <?php }  ?>
            </table>
            <table width="98%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td><div align="right"><span class="Partext1">
                    <?php

//Paging info
echo "Page ";


for($i = 1; $i <= $total_pages; $i++){ 
    if(($page) == $i){ 
        echo "$i "; 
        } else { 
            echo "&nbsp;[ <a href=\"".$_SERVER['PHP_SELF']."?page=$i\">$i</a>  ] "; 
    } 
} 


echo " of ". $total_pages ; 


// Build Previous Link 
if($page > 1){ 
    $prev = ($page - 1); 
    //echo "Page &nbsp;<a href=\"".$_SERVER['PHP_SELF']."?page=$prev\"><<Previous</a> "; 
	echo "&nbsp;<a href=\"".$_SERVER['PHP_SELF']."?page=$prev\"> Previous</a> &nbsp;|";
} 

// Build Next Link 
if($page < $total_pages){ 
    $next = ($page + 1); 
    echo "&nbsp;<a href=\"".$_SERVER['PHP_SELF']."?page=$next\">Next</a>"; 
} 
?>
                </span></div></td>
              </tr>
            </table></td>
        </tr>
      </table>
	  </td>
    <td width="226"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td>
		<?php 
$StrAction=$_GET['Action'];
if ($StrAction == "err")
{
	echo "<table width=97% border=0 cellpadding=0 cellspacing=0 >";
	echo "<tr>";
	echo "<td class=Alert><strong>Please Correct the  errors.</strong> </td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td class=Alert>";
	echo "Image format should be in .jpg  .gif  .png";
	echo "</br>";
	echo "Image file size below 350 KB";
	echo "</td>";
	echo "</tr>";
	echo "</table>";
}
?></td>
      </tr>
    </table>
    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
      <tr>
        <td>
		 <form action="success_story_submit.php" method="post" enctype="multipart/form-data"  name="photoform" id="photoform" onSubmit="MM_validateForm('BrideName','','R','BrideID','','R','GroomName','','R','GroomID','','R','WeddingDate','','R','Message','','R');return document.MM_returnValue" >
		<table width="85%" border="0" align="right" cellpadding="1" cellspacing="0">
          
          <tr>
            <td height="40"><div align="left" class="bodyp"><strong>Submit Success Story </strong></div></td>
            </tr>
          <tr>
            <td><input type="hidden" name="MAX_FILE_SIZE" value="1000000" /></td>
            </tr>
          
          <tr>
            <td>Wedding Photo : </td>
          </tr>
          <tr>
            <td width="56%"><input name="uploaded_file" type="file" class="bodysmall" id="uploaded_file" size="18" /></td>
            </tr>
          
          <tr>
            <td>Bride's Name :</td>
          </tr>
          <tr>
            <td><input name="BrideName" type="text" class="forminput" id="BrideName" maxlength="50"></td>
            </tr>
          <tr>
            <td>Bride's Matrimony ID : </td>
          </tr>
          <tr>
            <td><input name="BrideID" type="text" class="forminput" id="BrideID" maxlength="50"></td>
            </tr>
          
          
          <tr>
            <td>Groom's Name : </td>
          </tr>
          <tr>
            <td><input name="GroomName" type="text" class="forminput" id="GroomName" maxlength="50"></td>
            </tr>
          <tr>
            <td>Groom's Matrimony ID :</td>
          </tr>
          <tr>
            <td><input name="GroomID" type="text" class="forminput" id="GroomID" maxlength="50"></td>
            </tr>
          
          <tr>
            <td>Wedding Date : </td>
          </tr>
          <tr>
            <td><input name="WeddingDate" type="text" class="forminput" id="WeddingDate" maxlength="50"></td>
            </tr>
          
          <tr>
            <td>Write  about your marriage </td>
            </tr>
          <tr>
            <td><textarea name="Message" cols="20" rows="6" id="Message"></textarea></td>
            </tr>
          <tr>
            <td><input name="submit" type="submit" class="bodysg" value="Submit" onClick="return validate2()"></td>
            </tr>
        </table>
		 </form>
		</td>
      </tr>
    </table></td>
  </tr>
</table>
  <br></TD></TR>
</TABLE>

</DIV>
<!-- END LEFT PART -->	


		  
		    </TD>
    </TR>
			
          <TR>
            <TD><?php include("footer.php");?></TD>
          </TR>
          <TR>
          
    </TR>
          <TR>
         
          </TR>
  </TABLE>
  
</DIV>




</BODY>
</HTML>
