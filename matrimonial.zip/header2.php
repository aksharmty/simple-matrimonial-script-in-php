<!DOCTYPE html>
<html lang="en">
<head>
<title>Sukhmayrishtey.com - Online Shaadi Vivah &amp; Matrimony Site</title>
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
<script type="text/javascript" src="js/min.js"></script>
 <link rel="stylesheet" href="css/min.css" type="text/css" media="all">

  <!--[if lt IE 7]>
     <link rel="stylesheet" href="css/ie6.css" type="text/css" media="screen">
     <script type="text/javascript" src="js/ie_png.js"></script>
     <script type="text/javascript">
        ie_png.fix('.png, .nav-box .left, .nav-box .right, nav, footer .right, footer, #slider, #slider .inside a, .box .top, .box .bot, .link1, .link1 span, .link1 b, .list li, .main-box .left-top-corner, .main-box .right-top-corner, .main-box .border-top, .main-box .border-left, .main-box .border-right, .box1 .top, .box2 .top, .link2, .link3, .events-list li img, #subscribe-form span');
     </script>
<![endif]-->
<!--[if lt IE 9]>
        <script type="text/javascript" src="js/html5.js"></script>
  <![endif]-->

  <script type="text/javascript" src="js/jquery-555.js"></script>
 <script type="text/javascript">

    $(document).ready(function() {

        $(".tab_content").hide();
        $(".tab_content:first").show();

        $("ul.tabs li").click(function() {
            $("ul.tabs li").removeClass("active");
            $(this).addClass("active");
            $(".tab_content").hide();
            var activeTab = $(this).attr("rel");
            $("#" + activeTab).fadeIn();
        });
    });

</script> 

</head>
<body>
<div id="main">
  <!-- start top -->
  <div id="sr-top">
<p class="smr-top">

        <b class="pp"><a href="registration.php" title="Post Profile">Post Profile</a></b>
            <b class="li"><a href="login.php" title="Login">Login</a></b> <b class="awu"><a href="membership.php" title="Membership Plan">Membership Plan</a></b>
       
                
        </p>
                
</div>
      <!-- end top -->


<!-- start top -->
      <div id="header">
              <p class="help"><span><a href="help.php"><img src="images/help.gif" alt="" height="52" width="181"></a></span><br><br ><img alt="Phone " src="images/icon_receiver.gif" height="15" width="19"> Call Us : +91-8826007867,+91-8826007868</p>
           <p class="logo"><a href="#"><img alt="Home" src="images/logo.png" height="95px"></a></p>
          </div> <!-- end header --> 