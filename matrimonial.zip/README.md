# simple-matrimonial-script-in-php
simple matrimonial script in php requirement php5.3 and mysql 5.6.44
Make matrimonial website just download and upload all files in public_html folder and edit dbconnect.php with your mysql details
