<?php
include('dbconnect.php'); 
$water = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM siteconfig where id='1' "));
echo "$water";
?>  