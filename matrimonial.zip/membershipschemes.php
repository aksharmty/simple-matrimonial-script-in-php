<?php include("config.php"); ?>

<HTML>
<HEAD>
<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $info['Title']; ?></title>
<meta name="Description" content="<?php echo $info['Description']; ?>">
<meta name="keywords" content="<?php echo $info['Keywords']; ?>">
<LINK href="style.css" rel="stylesheet" type="text/css">

</HEAD>
<BODY class="body">



<DIV align="center">
<TABLE width="780" border="0" align="center" cellpadding="0" cellspacing="0" class="BlueTborder">
          <!--DWLayoutTable-->
          <TR>
            <TD height="37" colspan="2">
			<?php include("header.php");?>
			</TD>
    </TR>
          <TR>
            
    </TR>
          <TR>
            <TD  colspan="2"><?php include("topmenu.php");?></TD>
          </TR>
          <TR bgcolor="#FFFFFF">
            <TD colspan="2" valign="top">
			  

  
<!-- START LEFT PART -->  
<DIV align="center">
<TABLE width="100%" border="0" cellpadding="0" cellspacing="0">
<TR>
<TD width="180" height="303" valign="top" bgcolor="#F5F5F5">
<?php include("left1.php");?>
<?php include("leftbanner.php");?>
</TD>
<TD valign="top"><br>
      <table width="97%" height="20" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="37%" background="pics/heading_bg.gif"><div align="left">&nbsp;&nbsp;<strong>FREE MEMBER</strong></div></td>
          <td width="63%">&nbsp;</td>
        </tr>
      </table>
       
      <table width="97%" border="0" align="center" cellpadding="0" cellspacing="0" class="submenubox">
  <tr>
    <td><table width="98%" border="0" cellspacing="3" cellpadding="3">
      <tr>
        <td width="2%">&nbsp;</td>
        <td width="98%">Free Registration <br>
          View Photographs <br>
          Adding Photograph <br>
          Adding Horoscope <br>
          Receive Messages</td>
        </tr>
      
    </table></td>
  </tr>
</table>
      <p>&nbsp;</p>
      <table width="97%" height="20" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="37%" background="pics/heading_bg.gif"><div align="left">&nbsp;&nbsp;<strong>GOLDEN SCHEM (3 month)</strong></div></td>
          <td width="63%">&nbsp;</td>
        </tr>
      </table>
      <table width="97%" border="0" align="center" cellpadding="0" cellspacing="0" class="submenubox">
        <tr>
          <td><table width="98%" border="0" cellspacing="3" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
                <td>Adding Photograph <br>
                  Adding Horoscope <br>
                  View Photographs <br>
                  Adding Photograph <br>
                  Adding Horoscope <br>
                  View and Print Horoscopes <br>
                  Receive Messages <br>
                  Receive Addresses of Expected profiles<br>
                  Select Multiple options in Advance Search <br>
                  View More profiles in single line in a page<br>
                  View Addresses with permission 3 Months <br>
                  Payment Just Rs.600 (INR)</td>
              </tr>
          </table></td>
        </tr>
      </table>
      <p></p>      
      <table width="97%" height="20" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="37%" background="pics/heading_bg.gif"><div align="left">&nbsp;&nbsp;<strong>DIAMAND SCHEM (6 month)</strong></div></td>
          <td width="63%">&nbsp;</td>
        </tr>
      </table>
      <table width="97%" border="0" align="center" cellpadding="0" cellspacing="0" class="submenubox">
        <tr>
          <td><table width="98%" border="0" cellspacing="3" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
                <td>Adding Photograph <br>
                  Adding Horoscope <br>
                  View Photographs <br>
                  Adding Photograph <br>
                  Adding Horoscope <br>
                  View and Print Horoscopes <br>
                  Receive Messages <br>
                  Receive Addresses of Expected profiles<br>
                  Select Multiple options in Advance Search <br>
                  View More profiles in single line in a page<br>
                  View Addresses with permission 6 Months <br>
                  Payment Just Rs.1000 (INR)</td>
              </tr>
          </table></td>
        </tr>
      </table>
      <p></p>
      <table width="97%" height="20" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="37%" background="pics/heading_bg.gif"><div align="left">&nbsp;&nbsp;<strong>PLATINAM SCHEM (12 month)</strong></div></td>
          <td width="63%">&nbsp;</td>
        </tr>
      </table>
      <table width="97%" border="0" align="center" cellpadding="0" cellspacing="0" class="submenubox">
        <tr>
          <td><table width="98%" border="0" cellspacing="3" cellpadding="3">
              <tr>
                <td>&nbsp;</td>
                <td>Adding Photograph <br>
                  Adding Horoscope <br>
                  View Photographs <br>
                  Adding Photograph <br>
                  Adding Horoscope <br>
                  View and Print Horoscopes <br>
                  Receive Messages <br>
                  Receive Addresses of Expected profiles<br>
                  Select Multiple options in Advance Search <br>
                  View More profiles in single line in a page<br>
                  View Addresses with permission 12 Months <br>
                  Payment Just Rs.1800 (INR)</td>
              </tr>
          </table></td>
        </tr>
      </table>
      <p></p>
      <p>&nbsp;</p></TD>
</TR>
</TABLE>

</DIV>
<!-- END LEFT PART -->	


		  
		    </TD>
    </TR>
			
          <TR>
            <TD><?php include("footer.php");?></TD>
          </TR>
          <TR>
          
    </TR>
          <TR>
         
          </TR>
  </TABLE>
  
</DIV>




</BODY>
</HTML>
