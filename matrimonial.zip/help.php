<?php include("config.php"); ?>

<HTML>
<HEAD>
<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $info['Title']; ?></title>
<meta name="Description" content="<?php echo $info['Description']; ?>">
<meta name="keywords" content="<?php echo $info['Keywords']; ?>">
<LINK href="style.css" rel="stylesheet" type="text/css">
</HEAD>
<BODY class="body">
<DIV align="center">
<TABLE width="780" border="0" align="center" cellpadding="0" cellspacing="0" class="BlueTborder">
          <!--DWLayoutTable-->
          <TR>
            <TD height="37" colspan="2">
			<?php include("header.php");?>
			</TD>
    </TR>
          <TR>
            
    </TR>
          <TR>
            <TD  colspan="2"><?php include("topmenu.php");?></TD>
          </TR>
          <TR bgcolor="#FFFFFF">
            <TD colspan="2" valign="top">
			  

  
<!-- START LEFT PART -->  
<DIV align="center">
<TABLE width="100%" border="0" cellpadding="0" cellspacing="0">
<TR>
<TD height="303" valign="top" ><table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center">
      <table width="310" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="310" height="61" background="pics/livehelp.jpg"><table width="295" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="62">&nbsp;</td>
              <td width="233" rowspan="2">Chat with Live help<br>
                Our representatives will <br>
                guide you. <strong>Chat Now</strong> </td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              </tr>
          </table></td>
        </tr>
      </table>
    </div></td>
    <td><div align="center">
      <table width="311" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="313" height="61" background="pics/email.jpg"><table width="285" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td width="62">&nbsp;</td>
              <td width="223" rowspan="2"><strong>Email us</strong><br>
                 with all queries and doubts.<br>
<a href="mailto:<?php echo $info['ContactEmail']; ?>"><?php echo $info['ContactEmail']; ?> </a></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table></td>
        </tr>
      </table>
    </div></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2"><table width="314" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="310" height="61" background="pics/phone.jpg"><table width="290" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="62">&nbsp;</td>
            <td width="228" rowspan="2"><strong>Call us directly :<br>+91 </strong><br></td>                                                                                             
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">
        <TABLE width="100%" border="0" cellpadding="0" cellspacing="5">
          <!--DWLayoutTable-->
          <TR>
            <TD colspan="2">Questions</TD>
          </TR>
          <TR>
            <TD width="20">1.</TD>
            <TD width="517"><A href="#q1">How to fill the online registration form on <?php echo $info['WebFriendlyname']; ?> ?</A></TD>
          </TR>
          <TR>
            <TD>2.</TD>
            <TD><A href="#q2">How much money do I have to give to Register on <?php echo $info['WebFriendlyname']; ?> for membership?</A> </TD>
          </TR>
          <TR>
            <TD>3.</TD>
            <TD><A href="#q3">When does the registration get activated? </A></TD>
          </TR>
          <TR>
            <TD>4.</TD>
            <TD><A href="#q4">What is a <?php echo $info['WebFriendlyname']; ?> paid Membership? </A></TD>
          </TR>
          <TR>
            <TD>5.</TD>
            <TD><A href="#q5">What are the benefits of Registering on <?php echo $info['WebFriendlyname']; ?> ? </A></TD>
          </TR>
          <TR>
            <TD>6.</TD>
            <TD><A href="#q6">I already Registered but couldnot login to my <?php echo $info['WebFriendlyname']; ?> 's account why? </A></TD>
          </TR>
          <TR>
            <TD>7.<BR>            </TD>
            <TD><A href="#q7">I didn't receive an email. Now what do I do?</A></TD>
          </TR>
          <TR>
            <TD>8.</TD>
            <TD><A href="#q8">What are the benefits of the <?php echo $info['WebFriendlyname']; ?> paid Membership? </A></TD>
          </TR>
          <TR>
            <TD>9.</TD>
            <TD><A href="#q9">What are the benefits of Registering on <?php echo $info['WebFriendlyname']; ?> ?</A></TD>
          </TR>
          <TR>
            <TD>10.</TD>
            <TD><A href="#q10">What services do you offer for people without computer and Internet facility?</A></TD>
          </TR>
        </TABLE>
        <TABLE width="100%" border="0" cellpadding="0" cellspacing="5">
          <TR>
            <TD height="21">Answers.</TD>
          </TR>
          <TR>
            <TD width="550"><P align="justify"><span class="bodyp">1. How to fill the online registration form on <?php echo $info['WebFriendlyname']; ?> ? </span><BR>
                    Go to the online registration form. Fill out the required (marked * symbol) information as accurately and click on the Register button. We will send your user id and password to your email id, and you will become a Registered member of <?php echo $info['WebFriendlyname']; ?> . It is absolutely FREE of cost!&nbsp;&nbsp;&nbsp;&nbsp; <BR>
                      &nbsp;<A href="#top">Back to top</A> </P></TD>
          </TR>
          <TR>
            <TD>&nbsp;</TD>
          </TR>
          <TR>
            <TD><DIV align="justify"><span class="bodyp"><A name="q2"></A>2. How much money do I have to give to Register on <?php echo $info['WebFriendlyname']; ?> for membership? </span><BR>
                    It is absolutely FREE of cost. Submit your profile is absolutely free of cost. A nominal fee has to be paid to view the contact details of others. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A href="#top">Back to top</A>  </DIV></TD>
          </TR>
          <TR>
            <TD>&nbsp;</TD>
          </TR>
          <TR>
            <TD><DIV align="justify"><span class="bodyp"><A name="q3"></A>3. When does the registration get activated? </span><BR>
                    Once we get your registration form and your payment receipts are confirmed, your service will be activated and you can start using our services.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A href="#top">Back to top</A> </DIV></TD>
          </TR>
          <TR>
            <TD>&nbsp;</TD>
          </TR>
          <TR>
            <TD><DIV align="justify"><span class="bodyp"><A name="q4"></A>4. What is a <?php echo $info['WebFriendlyname']; ?> paid Membership? </span><BR>
                    Membership with which you are entitled to view the others profile on <?php echo $info['WebFriendlyname']; ?> is entirely FREE of cost. However, to view the contact details of other profiles on <?php echo $info['WebFriendlyname']; ?> there is a minimal service charge. This service is not available for non-paying FREE members of <?php echo $info['WebFriendlyname']; ?> .&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A href="#top">B</A><A href="#top">ack to top</A> </DIV></TD>
          </TR>
          <TR>
            <TD>&nbsp;</TD>
          </TR>
          <TR>
            <TD><DIV align="justify"><span class="bodyp"><A name="q5"></A>5. What are the benefits of Registering on <?php echo $info['WebFriendlyname']; ?> ? </span><BR>
                    You have to be Registered member for searching and viewing the profiles. <BR>
                      You have to be a paid member for viewing the contact details of profiles. <BR>
                      You can add information about yourself and your family - FREE.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A href="#top">B</A><A href="#top">ack to top</A> </DIV></TD>
          </TR>
          <TR>
            <TD>&nbsp;</TD>
          </TR>
          <TR>
            <TD><DIV align="justify"><span class="bodyp"><A name="q6"></A>6. I already Registered but cannot login to my <?php echo $info['WebFriendlyname']; ?> account. Why? </span><BR>
                    When you done Register on <?php echo $info['WebFriendlyname']; ?> you will get an USERNAME and PASSWORD after registration. That contains your <?php echo $info['WebFriendlyname']; ?> "userid (Matrimony ID)" and "password". If you have not received for whatever reasons, then your <?php echo $info['WebFriendlyname']; ?> account is still inactive. Then feel free to contact us and we will send your userid and password. &nbsp;<A href="#top">Back to top</A> </DIV></TD>
          </TR>
          <TR>
            <TD>&nbsp;</TD>
          </TR>
          <TR>
            <TD><DIV align="justify"><span class="bodyp"><A name="q7"></A>7. I didn't receive an email. Now what do I do? </span><BR>
                    Sometimes emails get lost. Or it is possible that you may have entered an incorrect email address by mistake. You can email us with the Name, username and email address that you used to Register, and we will go through it and get back to you as soon as possible.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A href="#top">Back to top</A> </DIV></TD>
          </TR>
          <TR>
            <TD>&nbsp;</TD>
          </TR>
          <TR>
            <TD><DIV align="justify"><span class="bodyp"><A name="q8"></A>8. What are the benefits of the <?php echo $info['WebFriendlyname']; ?> paid Membership? </span><BR>
                    The <?php echo $info['WebFriendlyname']; ?> paid Membership allows you to view the contact details of other Registered members and initiate contact with them. As a free member the applicant is allowed to search and view other member's profile but you cannot view their contact details. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A href="#top">B</A><A href="#top">ack to top</A> </DIV></TD>
          </TR>
          <TR>
            <TD>&nbsp;</TD>
          </TR>
          <TR>
            <TD><DIV align="justify"><span class="bodyp"><A name="q9"></A>9. What are the benefits of Registering on <?php echo $info['WebFriendlyname']; ?> ? </span><BR>
                    You get lots of FREE services when you Register on <?php echo $info['WebFriendlyname']; ?> . <BR>
                      You have to be Registered member for searching and viewing the profiles. <BR>
                      You have to be a paid member for viewing the contact details of profiles. <BR>
                      You can add information about yourself and your family - FREE. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A href="#top"></A><A href="#top">Back to top</A> </DIV></TD>
          </TR>
          <TR>
            <TD>&nbsp;</TD>
          </TR>
          <TR>
            <TD><DIV align="justify"><span class="bodyp"><A name="q10"></A>10. What services do you offer for people without computer and Internet facility? </span><BR>
                    If you do not have a computer, just fill in the application and send us your photograph with your full information and along with your registration charges. We will Register your details. You can see the other member details through our <?php echo $info['WebFriendlyname']; ?>  Site from any internet centre nearby.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<A href="#top"></A><A href="#top">Back to top</A> </DIV></TD>
          </TR>
        </TABLE>   </td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  
</table></TD>
</TR>
</TABLE>

</DIV>
<!-- END LEFT PART -->	


		  
		    </TD>
    </TR>
			
          <TR>
            <TD><?php include("footer.php");?></TD>
          </TR>
          <TR>
          
    </TR>
          <TR>
         
          </TR>
  </TABLE>
  
</DIV>




</BODY>
</HTML>