<?php include("config.php"); ?>

<HTML>
<HEAD>
<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $info['Title']; ?></title>
<meta name="Description" content="<?php echo $info['Description']; ?>">
<meta name="keywords" content="<?php echo $info['Keywords']; ?>">
<LINK href="style.css" rel="stylesheet" type="text/css">

</HEAD>
<BODY class="body">

<DIV align="center">
<TABLE width="780" border="0" align="center" cellpadding="0" cellspacing="0" class="BlueTborder">
          <!--DWLayoutTable-->
          <TR>
            <TD height="37" colspan="2">
			<?php include("header.php");?>
			</TD>
    </TR>
          <TR>
            <TD  colspan="2"><?php include("topmenu.php");?></TD>
          </TR>
          <TR bgcolor="#FFFFFF">
            <TD colspan="2" valign="top">
			  

  
<!-- START LEFT PART -->  
<DIV align="center">
<TABLE width="100%" border="0" cellpadding="0" cellspacing="0">
<TR>
<TD width="180" height="303" valign="top" bgcolor="#F5F5F5">
<?php include("left1.php");?>
<?php include("leftbanner.php");?>
</TD>
<TD valign="top"><br>
      <table width="97%" height="20" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="37%" background="pics/heading_bg.gif"><div align="left">&nbsp;&nbsp;<strong>Become a Dealer / Agent</strong></div></td>
          <td width="63%">&nbsp;</td>
        </tr>
      </table>
       
      <table width="97%" border="0" align="center" cellpadding="0" cellspacing="0" class="submenubox">
  <tr>
    <td><table width="98%" border="0" cellspacing="3" cellpadding="3">
      <tr>
        <td>&nbsp;</td>
        <td><br>
          <p><strong style="font-weight: 400">Start your own  business, We provide you an opportunity to start your own business here in the  web based matrimonial services.<br />
              <br />
Dealers are provided with a separate id and password. They can login in the  dealers/login area and enter the member information and view reports.<br />
<br />
Contact Us Immediately to get this golden opportunity in this noble services. </strong></p>
          <p><b>&nbsp;&nbsp; Sakhiraj Matrimonial</b></p>
	<p style="margin: 0 10px"><b>Address : - </b></p>
	<p style="margin: 0 10px">Delhi, 
	Delhi, India - 110005.</p>
	<p style="margin: 0 10px">&nbsp;</p>
	<p style="margin: 0 10px"><b>Email : - </b></p>
	<p style="margin: 0 10px">sakhiraj@yahoo.com</p>
	<p style="margin: 0 10px">&nbsp;</p>
	<p style="margin: 0 10px"><b>Call : -</b></p>
	<p style="margin: 0 10px">+91-</p>
		</td>
        </tr>
      
    </table></td>
  </tr>
</table>
      <p>&nbsp;</p></TD>
</TR>
</TABLE>

</DIV>
<!-- END LEFT PART -->	


		  
		    </TD>
    </TR>
			
          <TR>
            <TD><?php include("footer.php");?></TD>
          </TR>
          </TABLE>
  
</DIV>




</BODY>
</HTML>