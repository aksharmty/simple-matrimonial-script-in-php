<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-3282936-1");
pageTracker._initData();
pageTracker._trackPageview();
</script>
<table width="100%" height="20" border="0" cellpadding="0" cellspacing="0" bgcolor="#E0E0E0">
<tr>
<td>&nbsp;</td>
</tr>
</table>
