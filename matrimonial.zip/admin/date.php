<?php
 echo date('d-M-Y');
?>