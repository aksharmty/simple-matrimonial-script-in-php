<?
$plan = mysqli_query($con,"SELECT * from membershipplan ");
echo( '<select name="txtplan">' ); 
while($row = mysqli_fetch_array($plan))
{ 
echo  '<option value='.$row['plandisplayname'].'>'.$row['plandisplayname'].'</option>';
} 
echo '</select>';  
?>