<? session_start();
if(isset($_SESSION["adminusername"])){
header('location:index.php');
}
?>