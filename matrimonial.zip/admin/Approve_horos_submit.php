<?php include('protect.php'); ?>
<?php
include('../dbconnect.php'); 

$Strid = $_GET['ID'];
	// UPDATE HOROS STATUS from No to Yes
	$update1 = mysqli_query($con,"update register set HorosApprove='Yes' where MatriId = '$Strid'")
	or die("Could not update data because ".mysqli_error());
	
	//header('location:approve_horos.php?Action=Approved');
	 print "<script>";
     print " self.location='horosapproveconfirm.php';"; // Comment this line if you don't want to redirect
     print "</script>";
?>