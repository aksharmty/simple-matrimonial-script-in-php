<?php
include "../dbconnect.php";
$link_id = mysqli_connect();
if(!$link_id) die(sql_error());
echo "<i>Successfully made a connection to $dbhost.</i><br><br>";

$result = mysqli_query($con,"select version() into output file x.txt;",$link_id);
$affected_rows = mysqli_affected_rows($link_id);
echo $affected_rows;

?>
