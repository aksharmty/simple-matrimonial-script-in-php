READ ME:

-------------------------------
HIOX Users Online - b 1.0
-------------------------------

This software is developed and copyrighted by HIOX Softwares.
This is given under The GNU General Public License (GPL).
This version is HU0b 1.0

Feature:
a)Total count of user online.
b)Shows the statistics of users currently accesing the webpage.
c)User count based on 300 seconds time gap.
d)Max visitrs at any point of time.
e)Simple file based utility.

How To Use:
a)unzip HUOb_1_0.zip, You will get HUOb/count.txt, HUOb/ip.txt, HUOb/hiox_uo.php

b)Copy the below code in the web page where you want the count to be viewed.

<?php
include "./HUOb/hiox-uo.php";
?>

c)set read, write permission for the file ip.txt NOTE: Your file's should be named with .php extention. 
[if you filename is test.html rename it to test.php]. 


NOTE: if you use the counter in a page ./test.html, HUC dir should be present under the same path (i.e ./HUC/*).
I.e unzip the file under the directory where you have the webpage to use this counter.

Release Date HU0b 1.0 : 28-12-2004

On any suggestions mail to us at pro@hioxindia.com

Visit us at http://www.hscripts.com
Visit us at http://www.hioxindia.com
