<?php
session_start(); 
include ('../dbconnect.php');

$username = $_POST['username']; 
$password = $_POST['password']; 

$query = mysqli_query($con,"SELECT adminusername,adminpassword FROM adminlogin WHERE adminusername='".$_POST['username']."' AND adminpassword='".$_POST['password']."'"); 
$result = mysqli_num_rows($query); 
$row = $query->fetch_array(); 

if ($result == 1) 
{ 
$_SESSION["adminusername"] = $row["adminusername"]; 

echo "Success!";
 
} 
else 
{ 
echo 'Wrong username or password.'; 
} 

?> 