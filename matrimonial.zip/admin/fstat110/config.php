<?
/*
#####################################################################
#                          Free Statistics                          #
#                           Version 1.1.0                           #
#                       �2003 Free-Webhosts.com                     #
#####################################################################
*/


$host = "localhost";		# MySQL host name, usually localhost
$uid  = "root";		# MySQL user name
$pwd  = "selva";			# MySQL password
$db   = "matri";		# MySQL database name

$limit = 30;			# default show hits for last (this many) days
$bar_image  = "bar.gif";	# main bar image
$bar2_image = "bar2.gif";	# bar image for extra projected hits
$bar_width = 300;			# maximum width of the bars
$bar_height = 12;			# height of the bars
$no_cache = 1;			# 1=no cache page;  0=allow cache page

?>
