vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|31 Dec 2009 14:31:00 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|GID-DBCC6911B1F\\Administrator
vti_modifiedby:SR|GID-DBCC6911B1F\\Administrator
vti_timecreated:TR|31 Dec 2009 14:31:00 -0000
vti_cacheddtm:TX|31 Dec 2009 14:31:00 -0000
vti_filesize:IR|10955
vti_cachedtitle:SR|Free statistics - Daily Hits
vti_cachedbodystyle:SR|<body>
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Style-Type text/css
vti_charset:SR|windows-1252
vti_title:SR|Free statistics - Daily Hits
vti_backlinkinfo:VX|
