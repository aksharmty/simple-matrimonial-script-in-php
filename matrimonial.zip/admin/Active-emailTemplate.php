<html>
<body>
	<table width="600" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td><img src="../pics/email_top.gif" width="600" height="108"></td>
	</tr>
	<tr>
	<td background="../emailpics/email_middle.gif"><table width="600" border="0" cellspacing="2" cellpadding="2">
	<tr>
	<td width="10">&nbsp;</td>
	<td width="562" rowspan="3" valign="top"><p style='font:normal 12px Arial, MS Sans serif, tahoma;color:#000000;'>Dear , </p>
	<p style='font:normal 12px Arial, MS Sans serif, tahoma;color:#000000;'>Congratulations! Your profile on ..... has been validated and activated. You are now ready to search and contact millions of validated profiles for FREE.<br />
	<br />
	Log on to <a href='" & StrSite_Config_DURL & "' target='_blank' rel='nofollow'>......</a> now using the follwing information to find your dream partner.</p>
	<table width=382 border=0 align='center' cellpadding=2cellspacing=0 bordercolor=#FF6600 rules=all style='BORDER-RIGHT: #FF6600 1px ridge; BORDER-TOP: #FF6600 1px ridge; BORDER-LEFT: #FF6600 1px ridge; BORDER-BOTTOM: #FF6600 1px ridge'>
	" )
	StrBody.Append( "
	<tr>" )
	StrBody.Append( "
	<td style='font:normal 12px Arial, MS Sans serif, tahoma;color:#000000;'><div align='left'>Login ID:</div></td>
	" )
	
	StrBody.Append( "</tr>
	" )
	StrBody.Append( "
	<tr>" )
	StrBody.Append( "
	<td height='38' style='font:normal 12px Arial, MS Sans serif, tahoma;color:#000000;'><div align='left'>Password:</div></td>
	" )
	
	StrBody.Append( "</tr>
	
	</table>
	<p style='font:normal 12px Arial, MS Sans serif, tahoma;color:#000000;'>And while you are on the site we strongly encourage you to use as many features. This way you will understand how easy it is to use our site and more importantly find your life partner. Some of the key features that you could straight away start using are: </p>
	<p style='font:normal 12px Arial, MS Sans serif, tahoma;color:#000000;'><strong>UploadPhoto</strong>: 90% of members look for profiles with photos. Don't miss out on this chance. Add your photo now and increase your responses by 10 times. </p>
	<p style='font:normal 12px Arial, MS Sans serif, tahoma;color:#000000;'><strong>AssuredContact</strong>: Get your phone number validated for FREE and get a direct connection to your life partner. </p>
	<p style='font:normal 12px Arial, MS Sans serif, tahoma;color:#000000;'><strong>Addvideo</strong>: Add video clipping to your profile for FREE and increase your responses. </p>
	<p style='font:normal 12px Arial, MS Sans serif, tahoma;color:#000000;'>Everybody here at ...., wish you all the very best in your search for a life partner. Should you require any further assistance, do not hesitate to callour officeOR visit our 24/7 live support. OR send mail us to <a href='mailto:" & StrSite_Config_Email_From & "'>......</a> </p>
	<p style='font:normal 12px Arial, MS Sans serif, tahoma;color:#000000;'>Good luck in your search for a life partner. </p>
	<p style='font:normal 12px Arial, MS Sans serif, tahoma;color:#000000;'>With warm regards,<br />
	Customer Support Manager. <br>
	.....</p>
	<p style='font:normal 10px Arial, MS Sans serif, tahoma;color:#000000;'>You are receiving this mail as a registered member of " & StrSite_Config_FURL & ". Please add <a href='mailto:" & StrSite_Config_Email_From & "' target='_blank' rel='nofollow'>" & StrSite_Config_Email_From & "</a> to your address book to ensure delivery into your inbox. </p></td>
	<td width="8">&nbsp;</td>
	</tr>
	<tr>
	
	</tr>
	<tr>
	
	</tr>
	</table></td>
	</tr>
	<tr>
	<td><img src="../emailpics/email_bottom.gif" width="600" height="19"></td>
	</tr>
	</table>
</body>
</html>
