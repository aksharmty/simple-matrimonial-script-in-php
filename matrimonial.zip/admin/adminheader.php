<table width="100%" height="110" border="0" cellpadding="0" cellspacing="0">
<tr>
<td background="images/bg.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td height="76"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td width="30%" bgcolor="#FFFFFF"><img src="http://jyotishraj.webs.com/sakhihosting banner.png" border="0"/></td>
<td width="70%" bgcolor="#FFFFFF"><div align="right"><img src="images/as.gif"/></div></td>
</tr>
</table></td>
</tr>

<tr>
<td height="25"><div id="menu">
		<ul>	
			<li><a class="#" href="index.php" title="home">MY ADMIN </a></li>
			<li><a href="approvals.php" title="Articles">APPROVALS</a></li>
			<li><a href="setcontacts.php" title="Gallery">SET CONTACTS </a></li>
			<li><a href="renewals.php" title="Affiliates">RENEWALS</a></li>
			<li><a href="reports.php" title="Articles">REPORTS</a></li>
			<li><a href="others.php" title="Abous us">OTHERS</a></li>
			<li><a href="logout.php" title="Logout">LOGOUT</a></li>
		</ul>
	</div>
		
		</td>
</tr>
</table></td>
</tr>
</table>