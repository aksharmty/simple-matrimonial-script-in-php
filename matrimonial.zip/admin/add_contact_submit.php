<?php include('protect.php'); ?>
<?php
include '../dbconnect.php'; 
$strid = $_POST['txtID'];
$result = mysqli_query($con,"SELECT MatriID,Name,ConfirmEmail,Noofcontacts,Status, Memshipexpirydate, DATEDIFF( CURRENT_DATE, Memshipexpirydate ) AS expdays 
FROM register WHERE DATEDIFF( CURRENT_DATE, Memshipexpirydate ) <1 AND Status <> 'InActive' AND Status <> 'Active' AND MatriID = '$strid' ");

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Set Assured Contacts to Paid members</title>
<style type="text/css">
<!--
.style4 {color: #FF0000;
	font-weight: bold;
}
.style4 {color: #000000}
-->
</style>
</head>
<link href="style.css" rel="stylesheet" type="text/css">
<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0" id="Outer">
  <tr>
    <td><table width="100%" border="0" cellpadding="0" cellspacing="0" id="inner">
      <tr>
        <td colspan="2"><?php include("adminheader.php");?></td>
      </tr>
      <tr>
        <td bgcolor="#F7F7F7" width="20%" valign="top"><?php include("adminleft.php");?></td>
        <td width="80%"><table width="100%" border="0" cellpadding="1" cellspacing="1" id="content">
          <tr>
            <td height="22" colspan="3" valign="middle"><img src="images/icon3.gif" width="19" height="16" /></td>
            <td width="98%" height="22" valign="middle"><span class="headertext">SET ASSURED CONTACT ALLOCATIONS</span></td>
          </tr>
          <tr>
            <td colspan="4" valign="top" class="HeadText1"><br />
              <table width="98%" border="0" align="center" cellpadding="3" cellspacing="3">
                <tr>
                  <td class="smalltextred">Every Paid member has an allocated ASSURED CONTACTS (ability to view contact details other profiles). The number varies for each plan as per your setting. Hence,using this option, a paid member can TOPUP the assured contacts </td>
                </tr>
              </table>              
                <br />
				<form action="add_contact_no_submit.php" method="post">
				<?php
				
				
				if(mysql_num_rows($result) == 0){
				///echo "Nothing Selected";
				
				 print "<script>";
     print " self.location='set_contact_allocate.php?action=noteligible';"; // Comment this line if you don't want to redirect
     print "</script>";
				
				} else {
				
				while($row = $result->fetch_array())
				{  ?>
				
   				<table width="600" border="0" align="center" cellpadding="5" cellspacing="0" class="submenubox" id="tbl" runat="server" visible="false">
                    <tr>
                      <td width="33%" class="paratext"><div align="left">Matri ID : </div></td>
                      <td width="67%"><? echo $row['MatriID']; ?>
                        <input name="txtID" type="hidden" id="txtID" value="<?php echo $row['MatriID']; ?>" /></td>
                    </tr>
                    <tr>
                      <td class="paratext"><div align="left">Name : </div></td>
                      <td ><? echo $row['Name']; ?></td>
                    </tr>
                    <tr>
                      <td class="paratext"><div align="left">Email : </div></td>
                      <td ><? echo $row['ConfirmEmail']; ?></td>
                    </tr>
                    <tr>
                      <td class="paratext"><div align="left">Membsership : </div></td>
                      <td ><? echo $row['Status']; ?></td>
                    </tr>
                    <tr>
                      <td class="paratext"><div align="left">Expiry Date : </div></td>
                      <td ><? echo $row['Memshipexpirydate']; ?></td>
                    </tr>
                    <tr>
                      <td class="paratext"><div align="left">Remining Days : </div></td>
                      <td ><? echo $row['expdays']; ?></td>
                    </tr>
                    <tr>
                      <td class="paratext"><div align="left">Remining Assured Contacts : </div></td>
                      <td class="style4" ><? echo $row['Noofcontacts']; ?></td>
                    </tr>
                    <tr>
                      <td valign="middle" class="paratext"><div align="left"><span class="bluetext">Add  assured contacts:</span></div></td>
                      <td><br />
                        <select name="txtcontact" id="txtcontact">
                        <option value="10">10</option>
                        <option value="15">15</option>
                        <option value="20">20</option>
                        <option value="25">25</option>
                        <option value="30">30</option>
                        <option value="35">35</option>
                        <option value="40">40</option>
                        <option value="45">45</option>
                        <option value="50">50</option>
                        <option value="55">55</option>
                        <option value="60">60</option>
                        <option value="65">65</option>
                        <option value="70">70</option>
                        <option value="75">75</option>
                        <option value="80">80</option>
                        <option value="85">85</option>
                        <option value="90">90</option>
                        <option value="95">95</option>
                        <option value="100">100</option>
                      </select>
                        <br />
                        <span class="smalltextred">(Select number to this profile for View other member's Phone and address) </span></td>
                    </tr>
                    
                    <tr>
                      <td class="text11">&nbsp;</td>
                      <td class="text11"><input type="submit" name="Submit" value="Add Assured Contact" /></td>
                    </tr>
                  </table>
				
	<?php  } } ?>				

		
			
				
				
				</form>
				<p align="center">&nbsp;</p></td>
            </tr>
          
        </table></td>
      </tr>
      <tr>
        <td colspan="2"><?php include("adminfooter.php");?></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
