<?php include('protect.php'); ?>
<? 
// Database Connection 
include '../dbconnect.php'; 

////////// TOTAL MEMBERS
$Totaldata = mysqli_query($con,"SELECT Count(*) as Totalmembers FROM register") 
or die(mysqli_error()); 
$Tot = $Totaldata->fetch_array();

////////////TOT INACTIVE MEMBERS
$InActivedata = mysqli_query($con,"SELECT Count(MatriID) as TotInA FROM register where Status='InActive' ") 
or die(mysqli_error()); 
$InA = $InActivedata->fetch_array();

//////////// TOT ACTIVE MEMBERS
$Activedata = mysqli_query($con," SELECT Count(MatriID) as TotA FROM register where Status='Active' ") 
or die(mysqli_error()); 
$A = $Activedata->fetch_array( );

//////////// TOT PAID MEMBERS
$Paiddata = mysqli_query($con," SELECT Count(MatriID) as TotP FROM register where Status != 'Active' and Status != 'InActive' ") 
or die(mysqli_error()); 
$P =  $Paiddata ->fetch_array();

//////////// TOT FEATURED MEMBERS
$Feadata = mysqli_query($con," SELECT Count(MatriID) as TotFea FROM register where Status='Featured' ") 
or die(mysqli_error()); 
$Fea = $Feadata->fetch_array();

//////////// TOT PLATINUM MEMBERS
$Pladata = mysqli_query($con," SELECT Count(MatriID) as TotPla FROM register where Status='PLATINUM' ") 
or die(mysqli_error()); 
$Pla =  $Pladata->fetch_array();

//////////// TOT DIAMOND MEMBERS
$Diadata = mysqli_query($con," SELECT Count(MatriID) as TotDia FROM register where Status='DIAMOND' ") 
or die(mysqli_error()); 
$Dia =  $Diadata->fetch_array();

//////////// TOT GOLD MEMBERS
$Goldata = mysqli_query($con," SELECT Count(MatriID) as TotGol FROM register where Status='GOLD' ") 
or die(mysqli_error()); 
$Gol =  $Goldata->fetch_array();

//////////// TOT MALE MEMBERS
$Maledata = mysqli_query($con," SELECT Count(Gender) as TotMale FROM register where Gender='Male' ") 
or die(mysqli_error()); 
$Male =  $Maledata->fetch_array();

//////////// TOT FEMALE MEMBERS
$Femaledata = mysqli_query($con," SELECT Count(Gender) as TotFemale FROM register where Gender='Female' ") 
or die(mysqli_error()); 
$Female =  $Femaledata->fetch_array();

//////////// TOT HINDUS MEMBERS
$Hindudata = mysqli_query($con," SELECT Count(Religion) as TotHindus FROM register where Religion='Hindu' ") 
or die(mysqli_error()); 
$Hindus =  $Hindudata->fetch_array();

//////////// TOT CHRISTIANS MEMBERS
$Christdata = mysqli_query($con," SELECT Count(Religion) as TotChrist FROM register where Religion='Christian' ") 
or die(mysqli_error()); 
$Christ =  $Christdata->fetch_array();

//////////// TOT MUSLIMS MEMBERS
$Muslimdata = mysqli_query($con," SELECT Count(Religion) as TotMuslims FROM register where Religion='Muslim' ") 
or die(mysqli_error()); 
$Muslims =  $Muslimdata->fetch_array();

//////////// TOT SIKH MEMBERS
$Sikhdata = mysqli_query($con," SELECT Count(Religion) as TotSikh FROM register where Religion='Sikh' ") 
or die(mysqli_error()); 
$Sikh =  $Sikhdata->fetch_array();

?>

<link href="style.css" rel="stylesheet" type="text/css">
<table width="195" border="0" cellpadding="0" cellspacing="4">
  <tr>
    <td height="25" colspan="2" class="paratext"> <div align="center">Site Statistics </div></td>
  </tr>
  
  <tr>
    <td width="1%">&nbsp;</td>
    <td width="99%" class="smalltextgrey">Total Members : <span class="smalltextred"><?php echo $Tot['Totalmembers']; ?></span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">In Active Members : <span class="smalltextred"><?php echo $InA['TotInA']; ?></span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">Active Members : <span class="smalltextred"><?php echo $A['TotA']; ?></span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">Paid Members : <span class="smalltextred"><?php echo $P['TotP']; ?></span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">Featured Members : <span class="smalltextred"><?php echo $Fea['TotFea']; ?></span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">Platinum Members : <span class="smalltextred"><?php echo $Pla['TotPla']; ?></span></td>
  </tr>
<tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">Diamond Members : <span class="smalltextred"><?php echo $Dia['TotDia']; ?></span></td>
  </tr>
<tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">Gold Members : <span class="smalltextred"><?php echo $Gol['TotGol']; ?></span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">Male Profiles : <span class="smalltextred"><?php echo $Male['TotMale']; ?></span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">Female Profiles : <span class="smalltextred"><?php echo $Female['TotFemale']; ?></span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">Hindus : <span class="smalltextred"><?php echo $Hindus['TotHindus']; ?></span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">Christians : <span class="smalltextred"><?php echo $Christ['TotChrist']; ?></span></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">Muslims : <span class="smalltextred"><?php echo $Muslims['TotMuslims']; ?></span> </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td class="smalltextgrey">Sikh : <span class="smalltextred"><?php echo $Sikh['TotSikh']; ?></span> </td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr><td>&nbsp;</td>
  <td><iframe data-aa='1984262' src='//acceptable.a-ads.com/1984262' style='border:0px; padding:0; width:200px; height:200px; overflow:hidden; background-color: transparent;'></iframe></td></tr>
</table>
