<?php
include('dbconnect.php'); 
$info = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM siteconfig where id='1'")) 
or die(mysqli_error()); 
?>

  
