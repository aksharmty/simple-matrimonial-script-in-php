<?php
session_start();
include('dbconnect.php');
			// username and password sent from signup form 
		$myusername = mysqli_real_escape_string($con, $_POST['txtusername']); 
		$mypassword = md5($_POST['txtpassword']);
			 

			$sql="SELECT MatriID,ConfirmEmail,ConfirmPassword FROM register  WHERE MatriID= '$myusername'  and ConfirmPassword='$mypassword'  OR  ConfirmEmail='$myusername' and ConfirmPassword='$mypassword' ";
			$result = mysqli_query($con, $sql);  
           if(mysqli_num_rows($result) > 0)  
           {  
              while($row = $result->fetch_assoc()) {
                $_SESSION['username'] = $row['MatriID'];  
            
        // mysqli_num_row is counting table row
			$count=mysqli_num_rows($result);
			// If result matched $myusername and $mypassword, table row must be 1 row
			
			if($count==1){
$update1 = mysqli_query($con,"update register set Logincount=(Logincount+1) WHERE MatriID= '$myusername' OR ConfirmEmail='$myusername'");
			
			
			// Register $myusername, $mypassword and redirect to file "login_success.php"
     
			header('location:authenticate.php?Action=Success');
		    header($_SERVER['HTTP_REFERER']);
			}
            
            
            
            
                //header("location:loginbonus.php");
                //header("location:dashboard.php");
            } } 
            
			else {
			
			echo "Wrong Username or Password";
			ob_start();
?>

<?PHP
			header('location:login.php?Action=wrong');
			exit();
			
//ob_end_flush();

//}

}
?>


