<table width="170" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td height="21" >&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;
    <iframe data-aa='1984262' src='//acceptable.a-ads.com/1984262' style='border:0px; padding:0; width:100%; height:200px; overflow:hidden; background-color: transparent;'></iframe>
    <!-- script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4305348743992957"
     crossorigin="anonymous"></script>
<!-- sakhiadheader -->
<!--ins class="adsbygoogle"
     style="display:inline-block;min-width:120px;max-width:170px;width:100%;height:100%"
     data-ad-client="ca-pub-4305348743992957"
     data-ad-slot="1924539816"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script --></td>
  </tr>
 </table>
