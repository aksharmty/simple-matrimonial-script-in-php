<?php include("config.php"); ?>



<HTML>
<HEAD>
<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $info['Title']; ?></title>
<meta name="Description" content="<?php echo $info['Description']; ?>">
<meta name="keywords" content="<?php echo $info['Keywords']; ?>">
<LINK href="style.css" rel="stylesheet" type="text/css">

</HEAD>
<BODY class="body">



<DIV align="center">
<TABLE width="780" border="0" align="center" cellpadding="0" cellspacing="0" class="BlueTborder">
          <!--DWLayoutTable-->
          <TR>
            <TD height="37" colspan="2">
			<?php include("header.php");?>
			</TD>
    </TR>
          <TR>
            
    </TR>
          <TR>
            <TD  colspan="2"><?php include("topmenu.php");?></TD>
          </TR>
          <TR bgcolor="#FFFFFF">
            <TD colspan="2" valign="top">
			  

  
<!-- START LEFT PART -->  
<DIV align="center">
<TABLE width="100%" border="0" cellpadding="0" cellspacing="0">
<TR>
<TD width="180" height="303" valign="top" bgcolor="#F5F5F5">
<?php include("left.php");?>
<?php include("leftbanner.php");?>
</TD>
<TD valign="top"><br>
      <table width="97%" height="20" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="37%" background="pics/heading_bg.gif"><div align="left">&nbsp;&nbsp;<strong>Privacy Policy  </strong></div></td>
          <td width="63%">&nbsp;</td>
        </tr>
      </table>
       
      <table width="97%" border="0" align="center" cellpadding="0" cellspacing="0" class="submenubox">
  <tr>
    <td><table width="98%" border="0" align="center" cellpadding="1" cellspacing="1">
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><UL>
          <LI><?php echo $info['WebFriendlyname']; ?> is an online portal endeavoring       constantly to provide you with premium online       matrimonial services and it is designed to provide an       easy way for our members to meet each other on &nbsp;&nbsp;&nbsp;the Web.<br>
          </LI>
          <BR>
          <LI>This privacy statement is common to all the matrimonial       sites operated under <?php echo $info['WebFriendlyname']; ?>&nbsp;&nbsp;&nbsp;Since we are       strongly committed to your right to privacy, we have drawn out a privacy       statement with &nbsp;&nbsp;regard to the information we collect from  you. <br>
          </LI>
          <BR>
          <LI>All rights are reserved. All the information and       material presented on <?php echo $info['WebFriendlyname']; ?> is owned &nbsp;&nbsp;&nbsp;and       controlled by <?php echo $info['WebFriendlyname']; ?>. Any kind of reproduction, publication or       copying of the &nbsp;&nbsp;&nbsp;material &nbsp;&nbsp;&nbsp;or the       commercial use of information found on <?php echo $info['WebFriendlyname']; ?> is       prohibited without &nbsp;the express consent of <?php echo $info['WebFriendlyname']; ?>       online matrimonial service.<br>
</LI>
          <BR>
          <LI>Being an online matrimonial service we have to gather       certain information from our members, which is       &nbsp;&nbsp;&nbsp;essential, to enable us to provide you with profiles       that match your requirement. The information &nbsp;&nbsp;&nbsp;collected       on <?php echo $info['WebFriendlyname']; ?> cannot be used by anyone to ascertain the identity of a       particular&nbsp;individual <?php echo $info['WebFriendlyname']; ?> collects information like name,       address, contact, numbers, email, age, gender, personal characteristics,       religion/caste information, etc. are required to be put for the  &nbsp;&nbsp;&nbsp;other members to see who are searching for brides and       groom. Though the members can see this information they cannot use it to       ascertain the identity of any particular individual.<br>
          </LI>
          <BR>
          <LI>Contact and other information collected for contests  is used to notify the winners and award prizes and other such offers. <br>
          </LI>
          <BR>
          <LI>Survey information collected is used to monitor or improve the site usage experience.<br>
          </LI>
          <BR>
          <LI>While <?php echo $info['WebFriendlyname']; ?> takes care to prevent site  misuse, we strongly recommend you establish the authenticity and intent of       members before giving out personally identifiable information in your       messages.<br>
          </LI>
          <BR>
          <LI>We use your server, IP address, and browser-type related information in the general administration of our website.<br>
          </LI>
          <BR>
          <LI>We display Your online status just to enable visitors  to contact you immediately.<br>
          </LI>
          <BR>
          <LI>This site uses cookies to deliver various services and to keep track of your personal preferences. A cookie is a small text file that can be entered into the memory of your browser to help a website       recognize repeat users; facilitate the user's ongoing access to and use of  the site;&nbsp; allow a site to track       usage behavior;&nbsp; compile aggregate data for content improvements; and undertake targeted advertising. A       cookie is also used to save your login and password to facilitate your       access to this site.<br>
          </LI>
          <BR>
          <LI>We do not trade, rent or sell your private  information to anyone, unless required by the law. We share&nbsp;your private information to our paid registered members.<br>
</LI>
          <BR>
          <LI><?php echo $info['WebFriendlyname']; ?> may display your pics uploaded on the       site to promote the site either online or ofline<br>
          </LI>
          <BR>
          <LI><?php echo $info['WebFriendlyname']; ?> may update this policy from time to time.<br>
</LI>
          <BR>
          <LI>If you have any questions about this privacy       statement</LI>
           �&nbsp;please email us at <A href="mailto:<?php echo $info['ContactEmail']; ?>"><?php echo $info['ContactEmail']; ?></A>
        </UL>
          <br></td>
      </tr>
    </table></td>
  </tr>
</table>
      <p>&nbsp;</p></TD>
</TR>
</TABLE>

</DIV>
<!-- END LEFT PART -->	


		  
		    </TD>
    </TR>
			
          <TR>
            <TD><?php include("footer.php");?></TD>
          </TR>
          <TR>
          
    </TR>
          <TR>
         
          </TR>
  </TABLE>
  
</DIV>




</BODY>
</HTML>
