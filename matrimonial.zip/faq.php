<?php include("config.php"); ?>



<HTML>
<HEAD>
<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $info['Title']; ?></title>
<meta name="Description" content="<?php echo $info['Description']; ?>">
<meta name="keywords" content="<?php echo $info['Keywords']; ?>">
<LINK href="style.css" rel="stylesheet" type="text/css">

<style type="text/css">
<!--
.style16 {	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: x-small;
}
-->
</style>
</HEAD>
<BODY class="body">



<DIV align="center">
<TABLE width="780" border="0" align="center" cellpadding="0" cellspacing="0" class="BlueTborder">
          <!--DWLayoutTable-->
          <TR>
            <TD height="37" colspan="2">
			<?php include("header.php");?>
			</TD>
    </TR>
          <TR>
            <TD  colspan="2"><?php include("topmenu.php");?></TD>
          </TR>
          <TR bgcolor="#FFFFFF">
            <TD colspan="2" valign="top">
			  

  
<!-- START LEFT PART -->  
<DIV align="center">
<TABLE width="100%" border="0" cellpadding="0" cellspacing="0">
<TR>
<TD width="180" height="303" valign="top" bgcolor="#F5F5F5">
<?php include("left1.php");?>
<?php include("leftbanner.php");?>
</TD>
<TD valign="top"><br>
      <table width="97%" height="20" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="37%" background="pics/heading_bg.gif"><div align="left">&nbsp;&nbsp;<strong>FAQ</strong></div></td>
          <td width="63%">&nbsp;</td>
        </tr>
      </table>
       
      <table width="97%" border="0" align="center" cellpadding="0" cellspacing="0" class="submenubox">
  <tr>
    <td><table width="98%" border="0" cellspacing="3" cellpadding="3">
      <tr>
        <td width="2%">&nbsp;</td>
        <td width="98%"><p><span class="tbborder"><strong>How do I register in MatrimonialPHPScript.co.cc?</strong><br />
To Register, click on the Registration link in the home page. Fill all the  details asked in the form. After you submit your form, your profile will be  automatically created. It will be validated and it will be made online after  the validation. The validation process is 24 hours to 48 hours. <br />
<br />
<strong>How do I modify my profile details?</strong><br />
Login and click the Update your profile Info option. After changing all the  information click the 'Update' button.<br />
<br />
<strong>What is Registration No?</strong><br />
Automatically a Registration Number is generated after your successful  registration. You need this registration number for login and other future  reference.<br />
<br />
<strong>Where do I enter my expectations of my bride/groom?</strong><br />
In the registration form, Step 3 is the EXPECTED PROFILE option. Fill in the  Mother's thegai of two options and father's thegai of two options. Also you can  enter the living place and qualification of the expected alliance. <br />
<br />
<strong>How do I add a photo and horoscope to my profile?</strong><br />
After logging in using Reg.No and password, in the member home page click the  Add your photograph option to add your picture and click Add Your Horoscope  option to add your horoscope.<br />
<br />
<strong>How do I view a profile of the known registration number?</strong><br />
Enter the known registration number and click the 'View' Button.<br />
<br />
<strong>How do I change my password?</strong><br />
Login and click the Change Password option in your member home page.<br />
<br />
<strong>How can I avail offline assistance/agents help?</strong><br />
Call us anytime for the offline assistance help. we are here to help you  anytime to find your right match or click the Dealers/Agents List and contact  them.</span></p>
          </td>
        </tr>
      
    </table></td>
  </tr>
</table>
      </TD>
</TR>
</TABLE>

</DIV>
<!-- END LEFT PART -->	


		  
		    </TD>
    </TR>
			
          <TR>
            <TD><?php include("footer.php");?></TD>
          </TR>
          </TABLE>
  
</DIV>




</BODY>
</HTML>
