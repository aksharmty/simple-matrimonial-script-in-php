<?php

$title = 'PHP4 Image Upload';

$types = array('jpg', 'gif', 'png');
$maxsize = 1024*1024;

$upload_dir = 'Memphoto1/';

//language
$lang['E_TYPE'] = 'Wrong image type.';
$lang['E_SIZE'] = 'File seze is not acceptable.';

?>