<form name="form1" method="post" action="emailvalidate.php">
  Email : 
  <input name="email" type="text" id="email">
  <input type="submit" name="Submit" value="Submit">
</form>
