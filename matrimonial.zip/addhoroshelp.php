<?php include("config.php"); ?>

<HTML>
<HEAD>
<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php echo $info['Title']; ?></title>
<meta name="Description" content="<?php echo $info['Description']; ?>">
<meta name="keywords" content="<?php echo $info['Keywords']; ?>">
<LINK href="style.css" rel="stylesheet" type="text/css">

</HEAD>
<BODY class="body">



<DIV align="center">
<TABLE width="780" border="0" align="center" cellpadding="0" cellspacing="0" class="BlueTborder">
          <!--DWLayoutTable-->
          <TR>
            <TD height="37" colspan="2">
			<?php include("header.php");?>
			</TD>
    </TR>
          <TR>
            <TD  colspan="2"><?php include("topmenu.php");?></TD>
          </TR>
          <TR bgcolor="#FFFFFF">
            <TD colspan="2" valign="top">
			  

  
<!-- START LEFT PART -->  
<DIV align="center">
<TABLE width="100%" border="0" cellpadding="0" cellspacing="0">
<TR>
<TD width="180" height="303" valign="top" bgcolor="#F5F5F5">
<?php include("left1.php");?>
<?php include("leftbanner.php");?>
</TD>
<TD valign="top"><br>
      <table width="97%" height="20" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td width="37%" background="pics/heading_bg.gif"><div align="left">&nbsp;&nbsp;<strong>Adding Horoscope</strong></div></td>
          <td width="63%">&nbsp;</td>
        </tr>
      </table>
       
      <table width="97%" border="0" align="center" cellpadding="0" cellspacing="0" class="submenubox">
  <tr>
    <td><table width="98%" border="0" cellspacing="3" cellpadding="3">
      <tr>
        <td>&nbsp;</td>
        <td><ul>
          <li>Login using the registration number and password </li>
          <li>Click the 'Add your Horoscope' link in the members home page </li>
          <li>Type the necessary information in the Virtual Navamsa Chart seen in that page. </li>
          <li>Click the Save button <br>
          </li>
        </ul>
          <p>You can also send your Horoscope with the registration Id to our office. We do the scanning and adding photograph for you.. We are here.. </p>
          <p><b>&nbsp;&nbsp; Sakhiraj Metrimonial</b></p>
	<!--p style="margin: 0 10px"><b>Address : - </b></p>
	<p style="margin: 0 10px">11, Vishal Complex, S.V.Road, Andheri(w), Mumbai, 
	Maharashtra, India - 400012.</p -->
	<p style="margin: 0 10px">&nbsp;</p>
	<p style="margin: 0 10px"><b>Email : - </b></p>
	<p style="margin: 0 10px">sakhiraj@yahoo.com</p>
	<p style="margin: 0 10px">&nbsp;</p>
	<!--p style="margin: 0 10px"><b>Call : -</b></p>
	<p style="margin: 0 10px">+91 97254 77348</p -->
		</td>
        </tr>
      
    </table></td>
  </tr>
</table>
      <p>&nbsp;</p></TD>
</TR>
</TABLE>

</DIV>
<!-- END LEFT PART -->	


		  
		    </TD>
    </TR>
			
          <TR>
            <TD><?php include("footer.php");?></TD>
          </TR>
          </TABLE>
  
</DIV>




</BODY>
</HTML>
